package com.capgemini.appl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.exception.UniversityAdmissionException;
import com.capgemini.appl.util.JndiUtil;

public class UniversityDtoImpl implements UniversityDto {
	private JndiUtil jdbcUtill = null;

	public UniversityDtoImpl() throws UniversityAdmissionException {
		try {
			jdbcUtill = new JndiUtil();
		} catch (UniversityAdmissionException e) {
			throw new UniversityAdmissionException("Error In JNDI Connection");
		}
	}

	@Override
	public List<Application> showApplications()
			throws UniversityAdmissionException {

		// SHOWING DEATILS
		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;
		List<Application> list = new ArrayList<Application>();

		String Query = "select * from Application where status ='applied' ";
		try {

			connection = jdbcUtill.getConnection();
			stat = connection.prepareStatement(Query);
			rs = stat.executeQuery();

			while (rs.next()) {
				int Application_id = rs.getInt("Application_id");
				String full_name = rs.getString("full_name");
				java.sql.Date date_of_birth = rs.getDate("date_of_birth");
				String highest_qualification = rs
						.getString("highest_qualification");
				int marks_obtained = rs.getInt("marks_obtained");

				String goals = rs.getString("goals");
				String email_id = rs.getString("email_id");
				String Scheduled_program_id = rs
						.getString("Scheduled_program_id");
				String status = rs.getString("status");
				java.sql.Date Date_Of_Interview = rs
						.getDate("Date_Of_Interview");

				Application application = new Application(Application_id,
						full_name, date_of_birth, highest_qualification,
						marks_obtained, goals, email_id, Scheduled_program_id,
						status, Date_Of_Interview);

				list.add(application);
			}

			return list;

		} catch (SQLException e) {
			throw new UniversityAdmissionException("UNABLE TO FETCH DATA"+e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
					if (stat != null) {
						stat.close();
					}
					if (connection != null) {
						connection.close();
					}
				} catch (SQLException e) {
					throw new UniversityAdmissionException(
							"Connection Closing failed");
				}
			}

		}

	}

	@Override
	public boolean addProgram(ProgramsOffered p)
			throws UniversityAdmissionException {

		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;

		
		String Query = "insert into Programs_Offered values(?,?,?,?,?) ";
		try {
			connection = jdbcUtill.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, p.getProgramName());
			stat.setString(2, p.getDescription());
			stat.setString(3, p.getApplicantEligility());
			stat.setInt(4, p.getDuration());
			stat.setString(5, p.getDegree_certificate_offered());
			rs = stat.executeQuery();
			if (rs.next()) {
			
				return true;

			} else {

				throw new UniversityAdmissionException(
						"UNABLE TO INSERT>> USER REGESTRATION FAILED");

			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean deleteProgram(String ProgramName)
			throws UniversityAdmissionException {

		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;



		String Query = " DELETE FROM Programs_Offered WHERE ProgramName=? ";
		try {
			connection = jdbcUtill.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, ProgramName);
			rs = stat.executeQuery();
			if (rs.next()) {
			
				return true;

			} else {

				throw new UniversityAdmissionException("CAN NOT DELETE DATA");

			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean updateProgram(ProgramsOffered p)
			throws UniversityAdmissionException {

		PreparedStatement stat = null;
		Connection connection = null;
		String Query = "UPDATE Programs_Offered SET description = ?, applicant_eligibility=?,duration=?,degree_certificate_offered = ? WHERE ProgramName=? ";

		try {
			connection = jdbcUtill.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, p.getDescription());
			stat.setString(2, p.getApplicantEligility());
			stat.setInt(3, p.getDuration());
			stat.setString(4, p.getDegree_certificate_offered());
			stat.setString(5, p.getProgramName());
			int r = stat.executeUpdate();
					if (r>=1) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e1) {
			//throw new UniversityAdmissionException(	"CAN NOT UPADTE INTO Programs_Offered");
e1.printStackTrace();
		}
		return false;

	}

	@Override
	public boolean acceptOrRejectApplication(Application application)
			throws UniversityAdmissionException {

		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;
		String Query = "UPDATE Application SET status = ?, Date_Of_Interview=? WHERE Application_id=? ";

		try {
			connection = jdbcUtill.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, application.getStatus());
			stat.setDate(2, application.getDate_Of_Interview());
			stat.setInt(3, application.getApplication_id());
			rs = stat.executeQuery();
			if (rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e1) {
			throw new UniversityAdmissionException(
					"CAN NOT UPADTE INTO Application");

		}

	}

	@Override
	public List<ProgramsOffered> showProgramsOffereds()
			throws UniversityAdmissionException {

		// SHOWING DEATILS
		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;
		List<ProgramsOffered> list = new ArrayList<ProgramsOffered>();

		String Query = "select * from Programs_Offered ";
		try {

			connection = jdbcUtill.getConnection();
			stat = connection.prepareStatement(Query);
			rs = stat.executeQuery();

			while (rs.next()) {

				String degree_certificate_offered = rs
						.getString("degree_certificate_offered");
				int duration = rs.getInt("duration");
				String ProgramName = rs.getString("ProgramName");
				String applicantEligility = rs.getString("applicant_eligibility");
				String description = rs.getString("description");
				ProgramsOffered programsOffered = new ProgramsOffered(
						ProgramName, description, applicantEligility, duration,
						degree_certificate_offered);
				list.add(programsOffered);
			}

			return list;

		} catch (SQLException e) {
			//throw new UniversityAdmissionException("UNABLE TO FETCH DATA");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
					if (stat != null) {
						stat.close();
					}
					if (connection != null) {
						connection.close();
					}
				} catch (SQLException e) {
					throw new UniversityAdmissionException(
							"Connection Closing failed");
				}
			}

		}
		return list;

	}

}
