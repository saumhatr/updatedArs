package com.capgemini.appl.service;

import java.util.List;

import com.capgemini.appl.dao.UniversityDto;
import com.capgemini.appl.dao.UniversityDtoImpl;
import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.exception.UniversityAdmissionException;

public class UniversityServiceImpl implements UniversityService {
	UniversityDto Dto = null;

	public UniversityServiceImpl() throws UniversityAdmissionException {
		Dto = new UniversityDtoImpl();
	}

	@Override
	public List<Application> showApplications()
			throws UniversityAdmissionException {
		return Dto.showApplications();
	}

	@Override
	public boolean addProgram(ProgramsOffered p)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return Dto.addProgram(p);
	}

	@Override
	public boolean acceptOrRejectApplication(Application application)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return Dto.acceptOrRejectApplication(application);
	}

	@Override
	public boolean deleteProgram(String ProgramName)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return Dto.deleteProgram(ProgramName);
	}

	@Override
	public boolean updateProgram(ProgramsOffered p)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return Dto.updateProgram(p);
	}

	@Override
	public List<ProgramsOffered> showProgramsOffereds()
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return Dto.showProgramsOffereds();
	}

}
