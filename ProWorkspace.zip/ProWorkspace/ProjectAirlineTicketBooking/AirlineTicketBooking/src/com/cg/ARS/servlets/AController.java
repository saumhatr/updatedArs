package com.cg.ARS.servlets;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("*.do")
public class AController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cmd = request.getServletPath();
		String nextJsp = null;
		RequestDispatcher dispatcher = null;
		System.out.println(cmd);
		switch (cmd) {
		
		case "/home.do":
			nextJsp="home.jsp";
			break;
		
		
		case "/admin.do":
				nextJsp="admin.jsp";
				break;
			
		case "/adminLogin.do":
			String username = request.getParameter("userNm");
			String password = request.getParameter("password");
			if(username.equalsIgnoreCase("admin") && password.equalsIgnoreCase("admin")){
				nextJsp="adminHome.jsp";
			}
			break;
			
		case "/adminUpdate.do":
			nextJsp="adminUpdate.jsp";
			break;
			
			
		case "/executive.do":
			
			nextJsp = "executive.jsp";
			break;
			
		case "/user.do":
			nextJsp = "user.jsp";
			break;
			
		default:
			break;
		}
		dispatcher = request.getRequestDispatcher(nextJsp);
		dispatcher.forward(request, response);
	}

}
